# EVS-project-for-sustainable-development
A responsive and interactive website created for an Environmental Studies (EVS) project to spread awareness about Sustainable Development and the 17 Sustainable Development Goals (SDGs).  This project explains the concept of sustainable development, its three pillars (Environmental, Social, Economic), global challenges
