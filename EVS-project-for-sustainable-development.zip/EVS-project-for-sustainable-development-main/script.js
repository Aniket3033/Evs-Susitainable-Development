// Wait until the HTML is fully loaded before running interactive code.
document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".slide");
  const prevButton = document.getElementById("prevSlide");
  const nextButton = document.getElementById("nextSlide");
  const dotsContainer = document.getElementById("sliderDots");
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");
  const contactForm = document.getElementById("contactForm");
  const formMessage = document.getElementById("formMessage");

  let currentSlide = 0;
  let slideTimer;

  // Create one clickable dot for every carousel image.
  slides.forEach((slide, index) => {
    const dot = document.createElement("button");
    dot.className = "dot";
    dot.setAttribute("aria-label", `Show slide ${index + 1}`);
    dot.addEventListener("click", () => {
      showSlide(index);
      restartAutoSlide();
    });
    dotsContainer.appendChild(dot);
  });

  const dots = document.querySelectorAll(".dot");

  // Show a selected slide and update the active dot.
  function showSlide(index) {
    slides[currentSlide].classList.remove("active");
    dots[currentSlide].classList.remove("active");

    currentSlide = (index + slides.length) % slides.length;

    slides[currentSlide].classList.add("active");
    dots[currentSlide].classList.add("active");
  }

  // Move the carousel forward or backward.
  function moveSlide(direction) {
    showSlide(currentSlide + direction);
  }

  // Automatically change the slide every few seconds.
  function startAutoSlide() {
    slideTimer = setInterval(() => moveSlide(1), 4500);
  }

  // Restarting keeps manual clicks from instantly being overridden.
  function restartAutoSlide() {
    clearInterval(slideTimer);
    startAutoSlide();
  }

  prevButton.addEventListener("click", () => {
    moveSlide(-1);
    restartAutoSlide();
  });

  nextButton.addEventListener("click", () => {
    moveSlide(1);
    restartAutoSlide();
  });

  showSlide(0);
  startAutoSlide();

  // Toggle the navigation menu on small screens.
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("open");
  });

  // Close the mobile menu after a navigation link is selected.
  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navLinks.classList.remove("open");
    });
  });

  // Reveal elements with a soft animation when they scroll into view.
  const revealElements = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.14 }
  );

  revealElements.forEach((element) => observer.observe(element));

  // Show a friendly confirmation instead of sending form data to a server.
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    formMessage.textContent = "Thank you! Your green idea has been recorded.";
    contactForm.reset();
  });
});
